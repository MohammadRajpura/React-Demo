import ListGroup from "./components/ListGroup";

function App() {
  return <ListGroup />;
}

export default App;
